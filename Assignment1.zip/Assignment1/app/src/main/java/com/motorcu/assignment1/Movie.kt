package com.motorcu.assignment1

data class Movie (val title: String, val genre: String, val releaseDate: String,
             val director: String,
             val rating: String, val poster: Int){//constructor
    //Şimdilik zorluk çıkmasın diye bütün değişkenleri String yaptım sadece poster ıd int

}